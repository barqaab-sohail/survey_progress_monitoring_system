<?php

require __DIR__.'/mdb-workflow.php';

use App\Http\Controllers\Admin\AuditLogController;
use App\Http\Controllers\Admin\HierarchyController;
use App\Http\Controllers\Admin\MasterDataController;
use App\Http\Controllers\Admin\OrganizationController;
use App\Http\Controllers\Admin\TeamController;
use App\Http\Controllers\Admin\UserAssignmentController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Api\FieldSurveyApiController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\AutomaticSurveyProgressController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\FieldSurveyController;
use App\Http\Controllers\FieldSurveyTestController;
use App\Http\Controllers\GoogleDriveController;
use App\Http\Controllers\GpxCalculatorController;
use App\Http\Controllers\HtNetworkUpdateController;
use App\Http\Controllers\MdbEntryController;
use App\Http\Controllers\MdbVerificationController;
use App\Http\Controllers\MobileGpxController;
use App\Http\Controllers\PasswordResetController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ProgressQueueController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\SurveyEntryController;
use App\Http\Controllers\SurveyVerificationController;
use App\Http\Controllers\TeamWorkAssignmentController;
use App\Http\Controllers\TransformerController;
use App\Http\Controllers\TransformerMdbBuilderController;
use App\Http\Middleware\AutomaticSurveyProgressReadOnly;
use Illuminate\Support\Facades\Route;

Route::view('/privacy-policy', 'legal.privacy-policy')->name('privacy-policy');
Route::view('/terms-of-service', 'legal.terms-of-service')->name('terms-of-service');

Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'create'])->name('login');
    Route::post('/login', [AuthController::class, 'store'])->middleware('throttle:login')->name('login.store');
    Route::get('/forgot-password', [PasswordResetController::class, 'request'])->name('password.request');
    Route::post('/forgot-password', [PasswordResetController::class, 'email'])->middleware('throttle:password-reset')->name('password.email');
    Route::get('/reset-password/{token}', [PasswordResetController::class, 'form'])->name('password.reset');
    Route::post('/reset-password', [PasswordResetController::class, 'update'])->middleware('throttle:password-reset-submit')->name('password.update');
});

Route::middleware(['auth', 'active'])->group(function () {
    Route::prefix('ht-updates')->name('ht-updates.')->controller(HtNetworkUpdateController::class)->group(function () {
        Route::get('/', 'index')->name('index');
        Route::get('/feeder/{feeder}/kmz', 'export')->name('export');
        Route::get('/{update}', 'show')->name('show');
        Route::post('/{update}/review', 'review')->name('review');
        Route::post('/{update}/gpx', 'resolveGpx')->name('gpx');
        Route::get('/{update}/photos/{index}', 'photo')->whereNumber('index')->name('photo');
    });
    Route::middleware('role:super_admin,mdb_generator')->prefix('mobile-gpx')->name('mobile-gpx.')->controller(MobileGpxController::class)->group(function () {
        Route::get('/', 'index')->name('index');
        Route::post('/sources', 'upload')->middleware('throttle:20,1')->name('upload');
        Route::get('/{clientUuid}', 'show')->whereUuid('clientUuid')->name('show');
        Route::post('/{clientUuid}/preview', 'preview')->whereUuid('clientUuid')->name('preview');
        Route::post('/{clientUuid}/confirm', 'confirm')->whereUuid('clientUuid')->name('confirm');
        Route::post('/{clientUuid}/json', 'export')->whereUuid('clientUuid')->middleware('throttle:20,1')->name('export');
    });
    Route::prefix('gpx-calculator')->name('gpx-calculator.')->controller(GpxCalculatorController::class)->group(function () {
        Route::get('/', 'index')->name('index');
        Route::post('/', 'store')->middleware('throttle:10,1')->name('store');
        Route::post('/verified-transformer', 'verified')->middleware('throttle:30,1')->name('verified');
        Route::get('/{calculation}', 'show')->whereNumber('calculation')->name('show');
        Route::post('/{calculation}/preview', 'preview')->whereNumber('calculation')->middleware('throttle:120,1')->name('preview');
        Route::post('/{calculation}', 'update')->whereNumber('calculation')->middleware('throttle:30,1')->name('update');
    });
    Route::middleware('role:super_admin')->prefix('field-survey-test')->name('field-survey-test.')->group(function () {
        Route::get('/', [FieldSurveyTestController::class, 'index'])->name('index');
        Route::get('/bootstrap', [FieldSurveyApiController::class, 'bootstrap'])->name('bootstrap');
        Route::get('/records', [FieldSurveyTestController::class, 'records'])->name('records');
        Route::post('/sync', [FieldSurveyTestController::class, 'sync'])->name('sync');
        Route::post('/{clientUuid}/attachments', [FieldSurveyTestController::class, 'attach'])->whereUuid('clientUuid')->name('attach');
        Route::get('/attachments/{clientUuid}', [FieldSurveyTestController::class, 'download'])->whereUuid('clientUuid')->name('download');
    });
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::put('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::get('/', DashboardController::class)->name('dashboard');
    Route::middleware('role:super_admin')->prefix('mdb-builder')->name('mdb-builder.')->group(function () {
        Route::get('/', [TransformerMdbBuilderController::class, 'index'])->name('index');
        Route::get('/create', [TransformerMdbBuilderController::class, 'create'])->name('create');
        Route::post('/', [TransformerMdbBuilderController::class, 'store'])->name('store');
        Route::get('/{project}/edit', [TransformerMdbBuilderController::class, 'edit'])->name('edit');
        Route::put('/{project}', [TransformerMdbBuilderController::class, 'update'])->name('update');
        Route::get('/{project}/preview', [TransformerMdbBuilderController::class, 'preview'])->name('preview');
        Route::post('/{project}/export', [TransformerMdbBuilderController::class, 'export'])->middleware('throttle:10,1')->name('export');
        Route::get('/{project}/source/{kind}', [TransformerMdbBuilderController::class, 'source'])->where('kind', 'pdf|gpx')->name('source');
    });
    Route::middleware('role:mobile_survey_user,mdb_generator,survey_team_leader,super_admin,project_manager,management_viewer')->prefix('field-surveys')->name('field-surveys.')->group(function () {
        Route::get('/', [FieldSurveyController::class, 'index'])->name('index');
        Route::get('/attachments/{clientUuid}', [FieldSurveyController::class, 'download'])->whereUuid('clientUuid')->name('attachment');
        Route::get('/{clientUuid}/edit', [FieldSurveyController::class, 'edit'])->whereUuid('clientUuid')->name('edit');
        Route::patch('/{clientUuid}', [FieldSurveyController::class, 'update'])->whereUuid('clientUuid')->name('update');
        Route::delete('/{clientUuid}', [FieldSurveyController::class, 'destroy'])->whereUuid('clientUuid')->name('destroy');
        Route::get('/{clientUuid}', [FieldSurveyController::class, 'show'])->whereUuid('clientUuid')->name('show');
    });
    Route::get('/progress-queue', ProgressQueueController::class)->middleware('role:super_admin,project_manager,management_viewer,survey_team_leader,mdb_team_user,mdb_processing_user')->name('progress.queue');
    Route::get('/google-drive', [GoogleDriveController::class, 'index'])->name('google-drive.index');
    Route::post('/google-drive/duplicates/{sha256}/cleanup', [GoogleDriveController::class, 'cleanupDuplicates'])->middleware('role:super_admin')->where('sha256', '[a-f0-9]{64}')->name('google-drive.duplicates.cleanup');
    Route::post('/auth/google', [GoogleDriveController::class, 'connect'])->middleware('throttle:10,1')->name('google-drive.connect');
    Route::get('/auth/google/callback', [GoogleDriveController::class, 'callback'])->name('google-drive.callback');
    Route::delete('/google-drive', [GoogleDriveController::class, 'disconnect'])->name('google-drive.disconnect');
    Route::post('/logout', [AuthController::class, 'destroy'])->name('logout');

    Route::middleware('role:survey_team_leader,mdb_team_user,super_admin,project_manager')->prefix('transformer-gis')->name('transformers.')->group(function () {
        Route::get('/', [TransformerController::class, 'index'])->name('index');
        Route::get('/{transformer}', [TransformerController::class, 'show'])->name('show');
    });

    Route::middleware(['role:survey_team_leader,super_admin', AutomaticSurveyProgressReadOnly::class])->prefix('survey')->name('survey.')->group(function () {
        Route::get('/', [SurveyEntryController::class, 'index'])->name('index');
        Route::get('/create', [SurveyEntryController::class, 'create'])->name('create');
        Route::post('/', [SurveyEntryController::class, 'store'])->name('store');
        Route::get('/entries/{entry}/edit', [SurveyEntryController::class, 'edit'])->name('edit');
        Route::put('/entries/{entry}', [SurveyEntryController::class, 'updateEntry'])->name('update');
        Route::get('/returned', [SurveyEntryController::class, 'returned'])->name('returned');
        Route::put('/items/{item}/resubmit', [SurveyEntryController::class, 'update'])->name('resubmit');
    });

    Route::middleware('role:survey_team_leader,super_admin,project_manager,management_viewer')->prefix('survey-progress')->name('survey-progress.')->controller(AutomaticSurveyProgressController::class)->group(function () {
        Route::get('/', 'index')->name('index');
        Route::middleware('role:super_admin')->group(function () {
            Route::get('/sync-status', [AutomaticSurveyProgressController::class, 'syncStatus'])->name('sync-status');
            Route::post('/sync', 'sync')->middleware('throttle:5,1')->name('sync');
            Route::post('/feeders/{feeder}/length', 'calculate')->middleware('throttle:10,1')->name('length');
            Route::put('/feeders/{feeder}/mapping', 'mapping')->name('mapping');
            Route::get('/feeders/{feeder}/transcriptions', 'transcriptions')->name('transcriptions');
            Route::post('/feeders/{feeder}/transcriptions', 'saveTranscription')->name('transcriptions.store');
            Route::get('/feeders/{feeder}/sources/{source}', 'source')->name('source');
            Route::post('/drive/connect', 'connect')->name('drive.connect');
            Route::get('/drive/callback', 'callback')->name('drive.callback');
        });
    });

    Route::middleware('role:mdb_team_user,super_admin')->prefix('verification')->name('verification.')->group(function () {
        Route::get('/', [SurveyVerificationController::class, 'index'])->name('index');
        Route::post('/{item}/verify', [SurveyVerificationController::class, 'verify'])->name('verify');
        Route::post('/{item}/return', [SurveyVerificationController::class, 'return'])->name('return');
    });

    Route::middleware('role:mdb_team_user,super_admin')->prefix('mdb')->name('mdb.')->group(function () {
        Route::get('/', [MdbEntryController::class, 'index'])->name('index');
        Route::get('/create', [MdbEntryController::class, 'create'])->name('create');
        Route::post('/', [MdbEntryController::class, 'store'])->name('store');
        Route::get('/entries/{entry}/edit', [MdbEntryController::class, 'edit'])->name('edit');
        Route::put('/entries/{entry}', [MdbEntryController::class, 'update'])->name('update');
        Route::get('/returned', [MdbEntryController::class, 'returned'])->name('returned');
        Route::put('/items/{item}/resubmit', [MdbEntryController::class, 'resubmit'])->name('resubmit');
    });

    Route::middleware('role:mdb_processing_user,super_admin')->prefix('mdb-verification')->name('mdb-verification.')->group(function () {
        Route::get('/', [MdbVerificationController::class, 'index'])->name('index');
        Route::get('/history', [MdbVerificationController::class, 'history'])->name('history');
        Route::post('/items/{item}/verify', [MdbVerificationController::class, 'verify'])->name('verify');
        Route::post('/items/{item}/return', [MdbVerificationController::class, 'return'])->name('return');
    });

    Route::middleware('role:super_admin,project_manager,management_viewer')->prefix('reports')->name('reports.')->group(function () {
        Route::get('/', [ReportController::class, 'index'])->name('index');
        Route::get('/export.csv', [ReportController::class, 'csv'])->name('csv');
    });

    Route::middleware('role:super_admin')->prefix('legacy-admin')->name('admin.')->group(function () {
        Route::get('/assignments', [UserAssignmentController::class, 'index'])->name('assignments.index');
        Route::get('/assignments/options', [UserAssignmentController::class, 'options'])->name('assignments.options');
        Route::get('/assignments/survey/{assignment}/candidates', [UserAssignmentController::class, 'candidates'])->name('assignments.candidates');
        Route::post('/assignments', [UserAssignmentController::class, 'store'])->name('assignments.store');
        Route::get('/master-data', [MasterDataController::class, 'index'])->name('master.index');
        Route::get('/master-data/hierarchy', [HierarchyController::class, 'index'])->name('hierarchy.index');
        Route::post('/master-data/hierarchy/projects', [HierarchyController::class, 'project'])->name('hierarchy.projects.store');
        Route::post('/master-data/hierarchy/circles', [HierarchyController::class, 'circle'])->name('hierarchy.circles.store');
        Route::post('/master-data/hierarchy/divisions', [HierarchyController::class, 'division'])->name('hierarchy.divisions.store');
        Route::post('/master-data/hierarchy/sub-divisions', [HierarchyController::class, 'subDivision'])->name('hierarchy.sub-divisions.store');
        Route::post('/master-data/hierarchy/grid-stations', [HierarchyController::class, 'gridStation'])->name('hierarchy.grid-stations.store');
        Route::get('/master-data/feeders/{feeder}/edit', [MasterDataController::class, 'edit'])->name('master.edit');
        Route::put('/master-data/feeders/{feeder}', [MasterDataController::class, 'update'])->name('master.update');
        Route::post('/master-data/import', [MasterDataController::class, 'import'])->name('master.import');
        Route::get('/master-data/import-template', [MasterDataController::class, 'template'])->name('master.template');
        Route::get('/organizations', [OrganizationController::class, 'index'])->name('organizations.index');
        Route::post('/organizations', [OrganizationController::class, 'store'])->name('organizations.store');
        Route::put('/organizations/{organization}', [OrganizationController::class, 'update'])->name('organizations.update');
        Route::get('/users', [UserController::class, 'index'])->name('users.index');
        Route::post('/users', [UserController::class, 'store'])->name('users.store');
        Route::put('/users/{user}', [UserController::class, 'update'])->name('users.update');
        Route::get('/teams', [TeamController::class, 'index'])->name('teams.index');
        Route::post('/teams', [TeamController::class, 'store'])->name('teams.store');
        Route::put('/teams/survey/{team}', [TeamController::class, 'updateSurvey'])->name('teams.survey.update');
        Route::put('/teams/mdb/{team}', [TeamController::class, 'updateMdb'])->name('teams.mdb.update');
        Route::put('/teams/{team}/group', [TeamController::class, 'group'])->name('teams.group');
        Route::post('/teams/member', [TeamController::class, 'member'])->name('teams.member');
        Route::post('/teams/assign-feeder', [TeamController::class, 'assignFeeder'])->name('teams.assign-feeder');
        Route::get('/audit-log', AuditLogController::class)->name('audit.index');
        Route::post('/audit-log/preview-clear', [AuditLogController::class, 'preview'])->name('audit.preview');
        Route::get('/audit-log/clear-records.csv', [AuditLogController::class, 'records'])->name('audit.records');
        Route::post('/audit-log/clear', [AuditLogController::class, 'clear'])->name('audit.clear');
    });
    Route::middleware('role:survey_team_leader,super_admin')->prefix('team-work')->name('team-work.')->controller(TeamWorkAssignmentController::class)->group(function () {
        Route::get('/', 'index')->name('index');
        Route::post('/survey', 'assignSurvey')->name('survey.assign');
        Route::post('/survey/{assignment}/reassign', 'reassignSurvey')->name('survey.reassign');
        Route::post('/survey/{assignment}/return', 'returnSurvey')->name('survey.return');
    });
    Route::middleware('role:super_admin,data_entry_verification_team_leader,mdb_creation_team_leader')->prefix('team-work')->name('team-work.')->controller(TeamWorkAssignmentController::class)->group(function () {
        Route::get('/workflow', 'workflowIndex')->name('workflow');
        Route::post('/workflow', 'assignWorkflow')->name('workflow.assign');
    });
});
